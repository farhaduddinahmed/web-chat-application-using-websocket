-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2021 at 07:48 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat2`
--

-- --------------------------------------------------------

--
-- Table structure for table `chatrooms`
--

CREATE TABLE `chatrooms` (
  `id` int(100) NOT NULL,
  `userid` int(100) NOT NULL,
  `msg` varchar(250) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chatrooms`
--

INSERT INTO `chatrooms` (`id`, `userid`, `msg`, `created_on`) VALUES
(1, 2, 'Hello', '2021-04-08 04:40:56'),
(2, 4, 'Hi', '2021-04-08 04:43:22'),
(3, 2, 'What are you doing', '2021-04-08 04:51:48'),
(4, 2, 'hi', '2021-04-08 05:56:25'),
(5, 4, 'Hey there', '2021-04-08 06:02:19'),
(6, 2, 'Hi', '2021-04-08 07:43:44'),
(7, 2, 'How are you', '2021-04-08 07:44:34'),
(8, 4, 'I am fine', '2021-04-08 07:45:54');

-- --------------------------------------------------------

--
-- Table structure for table `chat_message`
--

CREATE TABLE `chat_message` (
  `chat_message_id` int(100) NOT NULL,
  `to_user_id` int(100) NOT NULL,
  `from_user_id` int(100) NOT NULL,
  `chat_message` mediumtext NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Yes','No') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_message`
--

INSERT INTO `chat_message` (`chat_message_id`, `to_user_id`, `from_user_id`, `chat_message`, `timestamp`, `status`) VALUES
(1, 4, 2, 'hi', '2021-04-08 16:08:42', 'Yes'),
(2, 2, 4, 'hello', '2021-04-08 16:08:54', 'Yes'),
(3, 2, 4, 'How are you', '2021-04-08 16:12:10', 'Yes'),
(4, 4, 2, 'I am fine ', '2021-04-08 16:12:27', 'Yes'),
(5, 2, 4, 'how old are you', '2021-04-08 16:16:59', 'Yes'),
(6, 4, 2, 'I am 24', '2021-04-08 16:40:42', 'Yes'),
(7, 2, 4, 'what a coincidence', '2021-04-08 16:18:07', 'Yes'),
(8, 2, 4, 'so am i', '2021-04-08 16:18:07', 'Yes'),
(9, 4, 2, 'hello', '2021-04-08 16:40:42', 'Yes'),
(10, 4, 2, 'Hi', '2021-04-08 17:45:22', 'Yes'),
(11, 2, 4, 'Hello', '2021-04-08 01:45:26', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `chat_user_table`
--

CREATE TABLE `chat_user_table` (
  `user_id` int(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_profile` varchar(250) NOT NULL,
  `user_status` enum('Disabled','Enable') NOT NULL,
  `user_created_on` datetime NOT NULL,
  `user_verification_code` varchar(250) NOT NULL,
  `user_login_status` enum('Logout','Login') NOT NULL,
  `user_token` varchar(100) NOT NULL,
  `user_connection_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_user_table`
--

INSERT INTO `chat_user_table` (`user_id`, `user_name`, `user_email`, `user_password`, `user_profile`, `user_status`, `user_created_on`, `user_verification_code`, `user_login_status`, `user_token`, `user_connection_id`) VALUES
(2, 'Forhad', 'iamfarhad.ahmed@gmail.com', 'farhad', 'images/287752264.JPG', 'Enable', '2021-04-08 08:38:32', 'f3736e96e55d3051a53750958e8ab43d', 'Login', 'a5a9c6c02a5356a68d1d7ea5dc6ec981', 100),
(4, 'Korra', 'ahmed.korra97@gmail.com', 'korraa', 'images/1196878796.jpg', 'Enable', '2021-04-08 16:42:44', '639defe3ae23c40ea50690096343ad39', 'Logout', '6b4efb0e35d71783b7d4abb4f5833095', 85);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatrooms`
--
ALTER TABLE `chatrooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`chat_message_id`);

--
-- Indexes for table `chat_user_table`
--
ALTER TABLE `chat_user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatrooms`
--
ALTER TABLE `chatrooms`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `chat_message_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `chat_user_table`
--
ALTER TABLE `chat_user_table`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
